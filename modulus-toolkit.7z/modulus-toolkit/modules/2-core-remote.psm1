#tlukas, 10.09.2024

#check if toolkit is in elevated state
if (Get-ElevatedState) {
    Write-Host "Loading 2-core-remote.psm1!" -ForegroundColor Cyan
    #Continue loading the psm1
} else {
    #Skipping the rest of the file
    Return;
}

<#INFO
- WinRM setup
- PSSessionConfig
- managing PS sessions
- #additional tests for PS sessions
#>

#region --- WinRM setup
function Set-WinRM-tlukas {
    $adapter = Get-NetConnectionProfile -name "modulusAT"
    if ($adapter.NetworkCategory -ne "Private") {
        Set-NetConnectionProfile -Name "modulusAT" -NetworkCategory Private
        Write-Host "Updated network adatper modulusAT to use NetworkCategory Private!" -ForegroundColor Yellow
    }
    
    Write-host "Adding 3VM scope to trusted users!" -ForegroundColor Yellow
    Set-Item WSMan:\localhost\Client\TrustedHosts -Value "ModulusDB,ModulusAPP,ModulusFS" -Force
    
    winrm quickconfig
}

function Set-WinRM-VM {
    $adapter = Get-NetConnectionProfile -InterfaceAlias "MODULUS"
    if ($adapter.NetworkCategory -ne "Private") {
        Set-NetConnectionProfile -InterfaceAlias "MODULUS" -NetworkCategory Private
        Write-Host "Updated network adatper MODULUS to use NetworkCategory Private!" -ForegroundColor Yellow
    }
    
    Write-host "Adding 3VM scope to trusted users!" -ForegroundColor Yellow
    Set-Item WSMan:\localhost\Client\TrustedHosts -Value "ModulusDB,ModulusAPP,ModulusFS,tlukasVM" -Force
    
    winrm quickconfig
    
    if (-not (Get-NetFirewallRule | Where-Object DisplayName -eq "Allow WinRM")) {
        New-NetFirewallRule -Name "Allow WinRM" -DisplayName "Allow WinRM" -Enabled True -Direction Inbound -Protocol TCP -LocalPort 5985    
    }
}
#endregion

#region --- PSSessionConfig
#TODO: should be moved into a function
if (-not (Get-PSSessionConfiguration -name "modulus-PS7" -ErrorAction SilentlyContinue)) {
    try {
        #Enable-PSRemoting 
        Register-PSSessionConfiguration -Name 'modulus-PS7' -StartupScript 'C:\Program Files\PowerShell\Modules\modulus-toolkit\modules\0-startup-remote.ps1'
        Restart-Service -Name "WinRM" -ErrorAction SilentlyContinue
    }
    catch {
        #TODO: maybe put some explanation here 
    }
}
#endregion

#region --- managing PS sessions
function Open-DB-Session {
    #variables needed
    $user   = "Administrator"
    $target = "ModulusDB"
    $cred   = Get-CredentialFromVault -User $user -Target $target
    
    #$sessDB = New-PSSession -ComputerName $target -Credential $cred
    $sessDB = New-PSSession -ComputerName $target -Credential $cred -ConfigurationName 'modulus-PS7'
    #$sessDB = New-PSSession -ComputerName $target -Credential $cred -ConfigurationName 'PowerShell.7.4.5'
    
    # Store the session ID or the session object for later use
    $global:open_sessDB = $sessDB

    # Rename the PowerShell window title
    #$windowTitle = "Remote Session: $target"
    #[Console]::Title = $windowTitle

    #enter connection
    Enter-PSSession $sessDB

    Invoke-Command -Session $sessDB -ScriptBlock {
        Write-Host "Session opened on $target" -ForegroundColor Yellow
        Set-Location -Path D:\OnlineData -ErrorAction SilentlyContinue

        # Map the I: drive within the remote session
        New-PSDrive -Name "I" -PSProvider "FileSystem" -Root "\\ModulusAPP\I" -Persist
    }
}

function Open-APP-Session {
    #variables needed
    $user   = "Administrator"
    $target = "ModulusAPP"
    $cred   = Get-CredentialFromVault -User $user -Target $target
    
    #$sessAPP = New-PSSession -ComputerName $target -Credential $cred
    $sessAPP = New-PSSession -ComputerName $target -Credential $cred -ConfigurationName 'modulus-PS7'
    #$sessAPP = New-PSSession -ComputerName $target -Credential $cred -ConfigurationName 'PowerShell.7.4.5'

    # Store the session ID or the session object for later use
    $global:open_sessAPP = $sessAPP

    # Rename the PowerShell window title
    #$windowTitle = "Remote Session: $target"
    #[Console]::Title = $windowTitle

    #enter connection
    Enter-PSSession $sessAPP
    
    Invoke-Command -Session $sessAPP -ScriptBlock {
        Write-Host "Session opened on $target" -ForegroundColor Yellow
        Set-Location -Path D:\Galaxis -ErrorAction SilentlyContinue

        # not needed on APP-server
        # Map the I: drive within the remote session
        #New-PSDrive -Name "I" -PSProvider "FileSystem" -Root "\\ModulusAPP\I" -Persist
    }
}

function Open-FS-Session {
    #variables needed
    $user   = "Administrator"
    $target = "ModulusFS"
    $cred   = Get-CredentialFromVault -User $user -Target $target
    
    #$sessFS = New-PSSession -ComputerName $target -Credential $cred
    $sessFS = New-PSSession -ComputerName $target -Credential $cred -ConfigurationName 'modulus-PS7'
    #$sessFS = New-PSSession -ComputerName $target -Credential $cred -ConfigurationName 'PowerShell.7.4.5'

    # Store the session ID or the session object for later use
    $global:open_sessFS = $sessFS

    # Rename the PowerShell window title
    #$windowTitle = "Remote Session: $target"
    #[Console]::Title = $windowTitle

    #enter connection
    Enter-PSSession $sessFS
    
    Invoke-Command -Session $sessFS -ScriptBlock {
        Write-Host "Session opened on $target" -ForegroundColor Yellow
        Set-Location -Path D:\OnlineData -ErrorAction SilentlyContinue

        # Map the I: drive within the remote session
        New-PSDrive -Name "I" -PSProvider "FileSystem" -Root "\\ModulusAPP\I" -Persist
    }
}

function Close-PS-Sessions {
    
    $sessCounter = 0

    if ($global:open_sessDB) {
        $sessCounter = $sessCounter + 1
        $sessName = $global:open_sessDB.ComputerName
        # Remove the PowerShell session
        write-host "Closing session to $sessName!" -ForegroundColor Green
        Remove-PSSession $global:open_sessDB
        # Clear the global variable
        Remove-Variable -Name open_sessDB -Scope Global
    } 
    if ($global:open_sessAPP) {
        $sessCounter = $sessCounter + 1
        $sessName = $global:open_sessAPP.ComputerName
        # Remove the PowerShell session
        write-host "Closing session to $sessName!" -ForegroundColor Green
        Remove-PSSession $global:open_sessAPP
        # Clear the global variable
        Remove-Variable -Name open_sessAPP -Scope Global
        
    } 
    if ($global:open_sessFS) {
        $sessCounter = $sessCounter + 1
        $sessName = $global:open_sessFS.ComputerName
        # Remove the PowerShell session
        write-host "Closing session to $sessName!" -ForegroundColor Green
        Remove-PSSession $global:open_sessFS
        # Clear the global variable
        Remove-Variable -Name open_sessFS -Scope Global
    } 
    if ($sessCounter -eq 0) {
        Write-host "No sessions to close!" -ForegroundColor Yellow
    }
    #[Console]::Title = "tlukas"
}
#endregion

#region --- #additional tests for PS sessions
<#
function Open-DB-conn {
    param (
        [string]$user = "Administrator",
        [string]$target = "ModulusDB"
    )
    
    # Fetch credentials
    $cred = Get-CredentialFromVault -User $user -Target $target
    if (-not $cred) {
        Write-Host "Failed to retrieve credentials. Exiting..." -ForegroundColor Red
        return
    }
    
    # Check if PowerShell 7 session is already open
    if ($global:open_sessDB) {
        Write-Host "A session to $target is already open." -ForegroundColor Yellow
        return
    }

    # Create new PSSession with PowerShell 7
    try {
        $sessDB = New-PSSession -ComputerName $target -Credential $cred -ConfigurationName 'modulus-PS7'
        if (-not $sessDB) {
            Write-Host "Failed to establish a session." -ForegroundColor Red
            return
        }
        $global:open_sessDB = $sessDB
        Write-Host "Session established with $target." -ForegroundColor Green
    }
    catch {
        Write-Host "Error establishing session: $_" -ForegroundColor Red
        return
    }

    # Rename the PowerShell window title
    try {
        $windowTitle = "Remote Session: $target"
        [Console]::Title = $windowTitle
    }
    catch {
        Write-Host "Failed to change window title." -ForegroundColor Yellow
    }

    # Enter the remote session and ensure PowerShell 7 environment
    try {
        Invoke-Command -Session $sessDB -ScriptBlock {
            & 'C:\Program Files\PowerShell\7\pwsh.exe' -NoExit -Command {
                Write-Host "Session opened on $($env:COMPUTERNAME) with PowerShell 7" -ForegroundColor Yellow
                Set-Location -Path D:\OnlineData -ErrorAction SilentlyContinue
            }
        }
        Enter-PSSession -Session $sessDB
    }
    catch {
        Write-Host "Failed to enter remote session: $_" -ForegroundColor Red
    }
}
#>
#endregion