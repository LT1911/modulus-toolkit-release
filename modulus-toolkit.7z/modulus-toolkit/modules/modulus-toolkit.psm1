#tlukas, 01.10.2024

#some output
Write-Host "Loaded modulus-toolkit v1.5!" -ForegroundColor red

#run a check upon startup
Assert-MOD-Components -Silent