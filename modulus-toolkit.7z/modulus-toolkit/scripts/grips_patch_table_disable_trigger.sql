alter trigger GRIPS_PATCH_TABLE_IUD disable;
exit;