update grips_patch_table set version='10.50.02';
commit;
exit;