alter trigger GRIPS_PATCH_TABLE_IUD enable;
exit;